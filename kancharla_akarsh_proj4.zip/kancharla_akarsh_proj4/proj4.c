#include<stdio.h>
#include <stdlib.h>
#include<time.h>
#include<string.h>

//infinite value for the initial weight array in prim
#define INFINITY 1000

//--------------krushkal's algorithm-------------------

int total_edges=0;
struct one_edge
{
	int v[2];
	int wt;
};

void union3(int *height, int *set, int repx, int repy)
{
	     if(height[repx]==height[repy])
				{
								height[repx]++;
								set[repy]=repx; //y's tree points to x's tree
				}
				else if(height[repy] < height[repx])
				{
					set[repy]=repx; //y's tree points to x's tree
				}

				else
				{
						set[repx]=repy;//x's tree points to y's tree
				}

}



int find3(int x,int *set)
{
	int root, node, parent;

//find root of tree with x
	root=x;
	while(root!=set[root])
		root=set[root];

//compress path from x to root
	node=x;
	while(node!=root)
	{
		parent=set[node];
		set[node]=root;//node points to root
		node=parent;
	}
	return root;
}

//function which is passed to qsort for sorting
int comparator(const void* a, const void* b)
{
    struct one_edge* a1 = (struct one_edge*)a;
    struct one_edge* b1 = (struct one_edge*)b;
    return a1->wt > b1->wt;
}


void kruskal(int n, int **kruskal_A)
{
	int current_total_edges=total_edges;
	int count=0;
	int i,j;
	int no_of_edges;
	//A struct array for all the edges
  struct one_edge edge_array[current_total_edges];
	//printf("edges : %d\n",current_total_edges);

  //filling the edges and their weights in edge_array
  i=0;
  while(i<n)
	{
		j=0;
	  while(j<n)
	  {
		  if(kruskal_A[i][j]!=0)
			{
				edge_array[count].v[0]=i;
			  edge_array[count].v[1]=j;
			  edge_array[count].wt=kruskal_A[i][j];
         count++;
		  }
			j++;
	  }
		i++;
	}


	//MST edges
	struct one_edge mst_edges[n-1];

	i=0;
	while(i<n-1)
	{
		mst_edges[i].wt=INFINITY;
		i++;
	}


//First edges should be sorted
//C library function
qsort(edge_array, current_total_edges, sizeof(edge_array[0]), comparator);



//Dynamically allocate memory for height and set
  int *set, *height;
  set= (int*) malloc(n * sizeof(int));
	height= (int*) malloc(n * sizeof(int));

	i=0;
  while(i<n)
  {
	  set[i]=i;
	  height[i]=0;
		i++;
  }
  no_of_edges=0;
  count=0;



//since total edges in mst = vertices - 1
  while(count<n-1 && (no_of_edges<current_total_edges))
  {
	  int ucomp=find3(edge_array[no_of_edges].v[0],set);
	  int vcomp=find3(edge_array[no_of_edges].v[1],set);
		//if edge not in mst, add it to mst
	  if(ucomp!=vcomp)
	  {
		  mst_edges[count++]=edge_array[no_of_edges];
		  union3(height, set, ucomp, vcomp);
  	}
	  		no_of_edges++;
  }

//initializing krushkal's matrix
  int final_kruskal_matrix[n][n];
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			final_kruskal_matrix[i][j]=0;
		}
	}

//filling kruskal's matrix
  i=0;
  while(i<n-1)
	{
		if(mst_edges[i].wt!=INFINITY)
		{
			final_kruskal_matrix[mst_edges[i].v[0]][mst_edges[i].v[1]] = mst_edges[i].wt;
			final_kruskal_matrix[mst_edges[i].v[1]][mst_edges[i].v[0]] = mst_edges[i].wt;
		}
   i++;
	}

//displaying kruskal's matrix
printf("Kruskal's matrix:\n");
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%02d  ",final_kruskal_matrix[i][j]);
		}
		printf("\n");
	}

printf("\n");

//displaying kruskal's mst
printf("Kruskal's MST:\n");
i=0;
  while(i<n-1)
	{
		if(mst_edges[i].wt!=INFINITY)
		{
			printf("V%d - V%d : %d\n", mst_edges[i].v[0]+1,mst_edges[i].v[1]+1,mst_edges[i].wt);
		}
		i++;
	}


printf("\n");
//freeing the allocated memory
free(set);
free(height);
}







//------------prim's algo----------------------------

int pickmin( int n, int queue[], int weight[])
{
	int i=0,min_weight=INFINITY,return_minimum;
	while(i<n)
	{
		if(weight[i]<min_weight)
		{

			if( queue[i]!=-1)
			{
				return_minimum=i;
				min_weight = weight[i];
			}

		}
		i++;
	}
	return return_minimum;
}



void prim(int n,int **A_Prim){
  int i, j, priority[n], weight[n], parent[n], vertices=n, final_prim_matrix[n][n];;

//initializing priority queue, weight array, parent array
	i=0;
	while(i<n)
  {
    priority[i]=i;
		weight[i]=INFINITY;
		parent[i]=-1;
		i++;
  }

  weight[0]=0;

//for all the vertices
  while(vertices>0)
  {
		//picking the min value from the priority queue
    int v=pickmin(n, priority, weight);
    priority[v]=-1;

    for(j=0; j<n; j++)
    {
			//initializing prim's matrix
      final_prim_matrix[vertices-1][j]=0;

			//checking if there is an edge or not
      if(A_Prim[v][j]>0)
      {
				if(A_Prim[v][j]<INFINITY)
				{
					if(A_Prim[v][j] < weight[j])
					{
						if(priority[j]!=-1){
						  parent[j]=v;
							weight[j]=A_Prim[v][j];
					   }
					}

				}
      }
     }

     vertices--;

   }


//storing the vertices of mst in prim's matrix
	 i=1;
	 while(i<n)
	 {
	 	if(weight[i]!=INFINITY)
	 	{
	 		final_prim_matrix[parent[i]][i]= weight[i];
			final_prim_matrix[i][parent[i]]= weight[i];

	 	}
	 	i++;
	 }

//printing prim's matrix
   printf("Prim's matrix:\n");
	 for(i=0;i<n;i++)
   {
     for(j=0;j<n;j++)
     {
       printf("%02d  ",final_prim_matrix[i][j]);
     }
     printf("\n");
   }

   printf("\n");


//To display the minimum spanning tree
   printf("Prim's MST\n");
	 i=1;
	 while(i<n)
	 {
		 if(weight[i]!=INFINITY)
		 {
			 printf("V%d - V%d : %d\n",parent[i]+1,i+1,weight[i]);
		 }
     i++;
	 }
	 printf("\n");


}





//-----------Main Function-------------------------------


int main()
{

  srand(time(0));
  int n;
  int i,j,k;
  char algo_name[10];
  int cmp;

  //for generating a random number between 5 and 10
  /*using num=(rand() % (upper-lower + 1)) + lower,  here lower =5, upper =10 */
  n = (rand() % 6) + 5;

	printf("randomly selected %d vertices\n",n);

  //Allocating memory for an adjacency matrix A of size n x n

  int **A=(int**) malloc(n * sizeof(int*));

  for(int i = 0; i < n; ++i)
  {
    A[i] =(int*) malloc(n * sizeof(int));
  }

//generating an adjacency matrix A of size n x n
  for (i=0;i<n;i++)
  {
    for(j=0;j<=i;j++)
    {
      if(i==j)
      {
        A[i][j]=0;
      }
      else
      {
        A[i][j]= (rand() % 10) + 1;  /*using A[i][j]=rand() % (upper-lower + 1)) + lower,  here lower =1, upper =10 */
        A[j][i]= A[i][j];
				total_edges++;
      }

    }
  }

	total_edges=total_edges*2;

//prints randomly generated adjacency matrix A
   printf("random matrix:\n");
   for(i=0;i<n;i++)
   {
     for(j=0;j<n;j++)
     {
       printf("%02d  ",A[i][j]);
     }
     printf("\n");
   }

   printf("\n");


//User Interface
   while(1)
   {
     printf("select the algorithm (type q to quit): ");
     scanf("%s",&algo_name);
     printf("\n");
     if(strcmp(algo_name,"prim")==0)
     {
       prim(n,A);
     }

     else if(strcmp(algo_name,"kruskal")==0)
     {
       kruskal(n,A);
     }

     else if(strcmp(algo_name,"q")==0)
     {
			 //deallocating the memory allocated to P[][] matrix
			   for(int i = 0; i < n; ++i)
			   {
			     free(A[i]);
			   }
			   free(A);
        exit(0);
     }

     else
     {
       printf("Error: I only have prim and kruskal algorithm\n");
     }

   }





  return 0;
}
