1. To compile the program, use 'make' command
2. To run it use './proj4'