#include<bits/stdc++.h>
#include <stdlib.h>
#include<time.h>


//To generate intermediate vertices between source vertex and destination vertex to obtain shortest path
void path(int m,int **Pr,int q,int r)
{
  if(Pr[q][r]!=-1)
  {
    path(m,Pr,q,Pr[q][r]);
    printf("V%d ",Pr[q][r]+1);
    path(m,Pr,Pr[q][r],r);
  }
  return;
}

void floyd()
{
  srand(time(0));
  int n;
  int i,j,k;

  //for generating a random number between 5 and 10
  /*using num=(rand() % (upper-lower + 1)) + lower,  here lower =5, upper =10 */
  n = (rand() % 6) + 5;
  printf("randomly selected n: %d\n",n);

  //creating an adjacency matrix A for size n x n
  int A[n][n];
  int **P =(int**) malloc(n * sizeof(int*));
  for(int i = 0; i < n; ++i)
  {
    P[i] =(int*) malloc(n * sizeof(int));
  }


  for (i=0;i<n;i++)
  {
    for(j=0;j<=i;j++)
    {
      if(i==j)
      {
        A[i][j]=0;
        P[i][j]=-1;
      }
      else
      {
        A[i][j]= (rand() % 10) + 1;  /*using A[i][j]=rand() % (upper-lower + 1)) + lower,  here lower =1, upper =10 */
        A[j][i]= A[i][j];
        P[i][j]=-1;
        P[j][i]=-1;
      }

    }
  }

//prints randomly generated adjacency matrix
printf("Adjacency matrix A\n");
for(i=0;i<n;i++)
{
  for(j=0;j<n;j++)
  {
    printf("%d  ",A[i][j]);
  }
  printf("\n");
}

printf("\n");

for(k=0;k<n;k++)
{
  for(i=0;i<n;i++)
  {
    for(j=0;j<n;j++)
    {
      if(A[i][j] > A[i][k] + A[k][j])
      {
        A[i][j]=A[i][k]+A[k][j];
        P[i][j]=k;
      }
    }
  }
}

//prints shortest path matrix
printf("Shortest path matrix\n");

  for(i=0;i<n;i++)
  {
    for(j=0;j<n;j++)
    {
      printf("%d  ",A[i][j]);
    }
    printf("\n");
  }
  printf("\n");
/*
//prints intermediate nodes matrix
  printf("P matrix(Intermediate nodes matrix)\n");
  for(i=0;i<n;i++)
  {
    for(j=0;j<n;j++)
    {
      printf("%d  ",P[i][j]+1);
    }
    printf("\n");
  }
*/
//to print shortest paths and their lengths
  for(i=0; i<n;i++)
  {
    printf("\nV%d-Vj:shortest path and length\n",i+1);
    for(j=0;j<n;j++)
    {
      printf("V%d ",i+1);
      path(n,P,i,j);
      printf("V%d: ",j+1);
      printf("%d",A[i][j]);
      printf("\n");
    }

    printf("\n");
  }

//deallocating the memory allocated to P[][] matrix
  for(int i = 0; i < n; ++i)
  {
    free(P[i]);
  }
  free(P);
}


int main()
{
  //call to floyd
  floyd();
  return 0;
}
