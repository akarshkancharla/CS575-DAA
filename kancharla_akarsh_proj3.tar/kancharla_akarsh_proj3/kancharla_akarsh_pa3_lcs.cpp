#include<bits/stdc++.h>


//prints length of LCS and also the LCS
void lcs( char *X, char *Y, int m, int n )
{

   int c[m+1][n+1];
   int i, j;

//initializing first column and first row to zero
   for (i=0; i<=m; i++)
   {
     c[i][0]=0;
   }

   for (j=0; j<=n; j++)
   {
     c[0][j]=0;
   }

//building c[m+1][n+1] in a bottom up fashion
   for (i=1; i<=m; i++)
   {
     for (j=1; j<=n; j++)
     {

       if (X[i-1] == Y[j-1])
       {
           c[i][j] = c[i-1][j-1] + 1;
       }

       else
       {
         if (c[i-1][j]>= c[i][j-1])
         {
           c[i][j] = c[i-1][j];
         }
         else
         {
           c[i][j] =  c[i][j-1];
         }
       }

     }
   }

  int len= c[m][n];  //length of LCS
  char s[len+1];     //char array to store LCS
  s[len]='\0';       //terminating character


  i=m;
  j=n;

//storing in LCS in s using c
  while(i>0 && j>0)
  {
    if(X[i-1]==Y[j-1])  //if current character in X and Y are the same, store current character in s
    {
      s[len-1]=X[i-1];
      i--;
      j--;
      len--;
    }

    else if(c[i-1][j]>c[i][j-1]) //else find largest of the two and go in the direction of larger value
    {
      i--;
    }
    else
    {
      j--;
    }
  }
  //printing length of LCS and LCS
   printf("Length of LCS: %d\n",c[m][n]);
   printf("LCS:%s\n",s);

}





//main function
int main(int argc,char* argv[])
{
  //if number of input strings > 2 throw an error
  if(argc>3)
  {
    printf("error\n");
    return -1;
  }

  int m = strlen(argv[1]);
  int n = strlen(argv[2]);

//input strings can't be of length greater than 100
  if( m>100 || n>100 )
  {
    printf("the string length too long\n");
    return -2;
  }

//call to lcs
  lcs( argv[1], argv[2], m, n );

  return 0;
}
