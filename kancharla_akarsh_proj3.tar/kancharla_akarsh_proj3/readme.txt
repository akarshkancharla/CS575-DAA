kancharla_akarsh_pa3_lcs.cpp contains solution to question 1
kancharla_akarsh_pa3_floyd.cpp contains solution to question 2

use 'make' command to compile both files at once

To run file kancharla_akarsh_pa3_lcs.cpp use
./lcs string1 string2

To run file kancharla_akarsh_pa3_floyd.cpp use
./floyd


