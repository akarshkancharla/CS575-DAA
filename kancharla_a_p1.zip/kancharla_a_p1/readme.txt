C
make
./DAA_Cards -m market_price_file.txt -p price_list_file.txt
