

#include <stdio.h> /* fprintf */
#include <stdlib.h>
#include <unistd.h> /* getopt */
#include<string.h>
#include<math.h>
#include<time.h>

int maxProfit;
int j=0; //size of one pricelistfile
int n_subsets;
int max_count=0;

struct Card{
  char name[36];
  int price;
  int profit;
};


int compute_max_profit(struct Card iset[], int w){

  maxProfit=0;
  struct Card *s=(struct Card *) malloc(sizeof(struct Card)*j);
  struct Card *m=(struct Card *) malloc(sizeof(struct Card)*j);
  int x=0;
  int sum_of_weights=0;
  int sum_of_weights_s=0;
  int profit_s=0;
  int count=0;



  while(x < j){
      sum_of_weights+=iset[x].price;
      x++;
  }
  //printf("%d  %d\n",sum_of_weights,w);
  x=0;

  if(sum_of_weights<=w){
    while(x < j){
        maxProfit+=iset[x].profit;
        x++;
    }
   //write  a return call with the structure as return value
   return maxProfit;
  }

  int b;
  n_subsets=pow(2.0,j);
  //printf("%d\n",n_subsets);
  int subset[j];
  int g=0;

  while(g<j){
    subset[g]=0;
    g++;
  }


  for(int y=0; y < n_subsets; y++){ //while more subsets to generate
    b = 1;

    sum_of_weights_s=0;
    profit_s=0;
    count=0;
    g=0;

    while(g<j){
      subset[g] = subset[g] + b;
			b = subset[g]/2;
			subset[g] = subset[g]%2;
      g++;
    }
/*
    for(int z=0;z<j;z++){
		    printf("%d",subset[z]);
		}
    printf("\n");
*/
    for(int z=0;z<j;z++){
      if(subset[z]==1){
        count++;
        sum_of_weights_s+=iset[z].price;
        profit_s+=iset[z].profit;
      }
    }
    //printf("%d\n",profit_s);

    if (sum_of_weights_s<=w){
      if (profit_s > maxProfit){
        maxProfit=profit_s;
        max_count=count;
        for (int i=0; i<count; i++) {
           m[i] = s[i]; /* copy the whole struct s to m */
        }
      }
    }
  }
  return maxProfit;


}


int main(int argc, char *argv[]){
  clock_t begin;
  clock_t end;
  FILE *market_price_file, *price_list_file, *output_file;
  int line;
  char *line_buf = NULL;
  size_t line_buf_size = 0;
  int return_value=0;
  int pro=0;
  output_file=fopen("output.txt","w+");

    int opt;
    while((opt = getopt(argc, argv, "m:p:"))!=-1) {

        switch (opt) {
        case 'm':
            market_price_file=fopen(optarg,"r");
            break;

        case 'p':
           price_list_file=fopen(optarg,"r");
           break;

        default:
            /* Unexpected option */
           return 1;
        }
    }

//market price file parsing
   int i=0;
   int c=getline(&line_buf,&line_buf_size,market_price_file);
   int market_n=atoi(line_buf);
   struct Card market_cards[market_n];

    while(c=getline(&line_buf,&line_buf_size,market_price_file)!=-1 && i<market_n){
        strcpy(market_cards[i].name,strtok(line_buf," "));
        market_cards[i].price=atoi(strtok(NULL," "));
        i++;
        }

/*    while(j<market_n){
      printf("%s  ",market_cards[j].name);
      printf("%d\n",market_cards[j].price );
      j++;
    }
*/

//price list file parsing

    int total_weight;

    while(c=getline(&line_buf,&line_buf_size,price_list_file)!=-1)
    {
      begin=clock();
      j=atoi(strtok(line_buf," "));
      struct Card g_cards[
      j];
      total_weight=atoi(strtok(NULL," "));
      i=0;
      while(i<j){
          c=getline(&line_buf,&line_buf_size,price_list_file);
          strcpy(g_cards[i].name,strtok(line_buf," "));
          g_cards[i].price=atoi(strtok(NULL," "));

         int k;
          k=0;
         while(k<market_n)
          {
            if(strcmp(g_cards[i].name,market_cards[k].name)==0){
              g_cards[i].profit=market_cards[k].price - g_cards[i].price;
              break;
            }
            k++;
          }


          i++;
      }



     pro=compute_max_profit(g_cards,total_weight);
     //printf("%d\n",compute_max_profit(g_cards,total_weight));
     //printf("%d\n",max_count);
     end=clock();
     //fputc(j,output_file);//size of input
     //fputc(atoi(" "),output_file);
     //fputc(pro,output_file);//max profit
     //fputc(atoi(" "),output_file);
     //fputc(max_count,output_file);//count of max subset array
     //fputc(atoi(" "),output_file);
     //fputc((end-begin),output_file);//time for running

     fprintf(output_file, "%d %d %d %f\n", j, pro, max_count, ((double)(end - begin)) / CLOCKS_PER_SEC);
     //fputc(atoi("\n"),output_file);
/*
     int i=0;
      while(i<j){
        printf("%s  ",g_cards[i].name);
        printf("%d\n",g_cards[i].price );
        printf("%d\n",g_cards[i].profit );
        i++;
      }
*/
    }



    fclose(market_price_file);
    fclose(price_list_file);
    fclose(output_file);
    return 0;
}
