#include<stdio.h>
#include <stdlib.h>
#include<time.h>
#include<string.h>
#include<math.h>

int main(int argc, char *argv[])
{
  int i;
  srand(time(0));
  int sum=0;
  int W;
  FILE *fp;
//for generating n random items
  /*using num=(rand() % (upper-lower + 1)) + lower,  here lower =5, upper =10 */
  int n=(rand() % 5) + 4;
  //printf("n value is %d\n", n);

//for generating the profit and wieght array
  int p[n],w[n];

  for(i=0;i<n;i++)
  {
    p[i]=(rand() % 21) + 10;
    w[i]=(rand() % 16) + 5;
  }
//calculating total sum
  for(i=0;i<n;i++)
  {
    sum+=w[i];
  }

  W = (int)floor(0.6 * sum);

  fp=fopen(argv[2],"w+");
  if ( fp == NULL )
   {
       printf( "File open failed\n" );
   }
//outputting to a file
   fprintf(fp,"%d %d\n",n,W );
   for(i=0;i<n;i++)
   {
     fprintf(fp,"Item%d    %d   %d\n",i+1,p[i],w[i]);
   }

  fclose(fp);

}
