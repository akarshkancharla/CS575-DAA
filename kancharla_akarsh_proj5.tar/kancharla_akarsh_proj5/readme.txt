1) To Compile all the files, use 'make' command
2)Then run ./createkn01 -k knapsack01.txt  to create a random file to input
3)then you can run any of the algorithms using
./bruteforce -k knapsack01.txt
./dynpro -k knapsack01.txt
./backtrack -k knapsack01.txt
