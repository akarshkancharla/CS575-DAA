#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#include <unistd.h>

//dynamic arrays for storing the included element and the profit
int **included;
int **dynamicArray;

//checks if the inserted items are zero or not
int check(int size)
{
	if(size==0)
	{
		return 1;
	}
		return 0;
}

//checks if the sack is empty
int check_sack(int size)
{
	if(size<=0)
	{
		return 1;
	}
		return 0;
}
//actual function for dynamic knapsack refinement
int dynamic_knapsack(int *dynamicProfit,int *dynamicWeight,int c,int size)
{
	int inc,exc;
	int i=size-1;
	//call to the check() function
	if(check(size))
	{
		return 0;
	}
	//call to the check_sack() function
	if(check_sack(c))
	{
		return 0;
	}
    while(i>=0){
			if(c < dynamicWeight[i])
			{
				//donot include if this condition is satisfied
				included[size][c] = 0;
				return dynamic_knapsack(dynamicProfit,dynamicWeight,c,size-1);
			}

      //two recursive calls are made
			//one with same capacity and the other with decreased capacity
			inc = dynamic_knapsack(dynamicProfit,dynamicWeight,c,size-1);
			exc = dynamicProfit[i] + dynamic_knapsack(dynamicProfit,dynamicWeight,c-dynamicWeight[i],size-1);
     //satisfies only if the inc is greater than exc
      if(exc < inc)
			{
				//include if this condition is satisfied
				dynamicArray[size][c] = inc;
				included[size][c] = 0;
				return inc;
			}
			else
			{
				//exclude if the condition fails
				dynamicArray[size][c] = exc;
				included[size][c] = 1;
				return exc;
			}
      //decrement i after every iteration
			i--;
		}


		return 0;
}

//main function
int main(int argc,char*argv[])
{

  int totalProfit = 0,totalWeight=0;
  int count = 0;
  int p,w,j;
  int c;
  char *line_buf = NULL;
  size_t line_buf_size = 0;
  FILE *knapsack_file;

//to read from the command line
  int opt;
  while((opt = getopt(argc, argv, "k:"))!=-1) {

      switch (opt) {
      case 'k':
         knapsack_file=fopen(optarg,"r");
         break;

      default:
          /* Unexpected option */
         return 1;
      }
  }


//opens two file descriptors

	FILE *output2 = fopen("output2.txt","w");//for output2.txt file
  FILE *entries2 = fopen("entries2.txt","w");//for entries2.txt file



  int total_weight;
  c=getline(&line_buf,&line_buf_size,knapsack_file);

	j=atoi(strtok(line_buf," "));

  total_weight=atoi(strtok(NULL," "));

//dynamic memory allocation
  included=(int**) malloc(10 * sizeof(int*));
  dynamicArray=(int**) malloc(10 * sizeof(int*));


    for(int i = 0; i < 10; ++i)
    {
      included[i] =(int*) malloc(100 * sizeof(int));
    }


    for(int i = 0; i < 10; ++i)
    {
      dynamicArray[i] =(int*) malloc(100 * sizeof(int));
    }

//dynamically allocating memory for profit,weight,name pointers
	int *profit=(int*) malloc(j * sizeof(int));;
	int *weight=(int*) malloc(j * sizeof(int));;
  char **name=(char**) malloc(j * sizeof(char*));

  for(int i = 0; i < j; i++)
  {
    name[i] =(char*) malloc(36 * sizeof(char));
  }


	int i = 0;
//initializing the dynamic arrays
  while(i<j){
      c=getline(&line_buf,&line_buf_size,knapsack_file);
      strcpy(name[i],strtok(line_buf," "));
      profit[i]=atoi(strtok(NULL," "));
      weight[i]=atoi(strtok(NULL," "));
      i++;
  }


//call to the dynamic_knapsack function
	totalProfit = dynamic_knapsack(profit,weight,total_weight,j);

//assigning total weight to a temporary variable
  int tweight = total_weight;
//assigning the number of items to a temporary variable
	int tj = j;

//calculate the total weight
	i=0;
	while(i<j){
		if(included[tj][tweight] == 1)
		{
			//perform this only if it is included
			totalWeight +=  weight[tj-1];
			count++;
			tweight -=  weight[tj-1];
		}
		tj--;
		i++;
	}

//printing to a textfile
	fprintf(output2,"%d %d %d\n",count,totalProfit,totalWeight);

	int temp_weight=total_weight;
	int tempItems=j;

	i=1;
  while(i<=j){
		//output to text file only if it is included
		if(included[tempItems][temp_weight] == 1)
		{
 			fprintf(output2,"%s %d %d\n",name[tempItems-1],profit[tempItems-1],weight[tempItems-1]);
 			temp_weight = temp_weight - weight[tempItems-1];
		}
		i++;
		tempItems--;
	}

  i=1;
	int z;
	while(i<=j){
		//output the entries to entries2.txt file
		fprintf(entries2,"row%d ",i);
    z=1;
		while(total_weight>=z){
			if(dynamicArray[i][z] != 0)
			//if(included[i][z] == 1)
			{
				fprintf(entries2,"  %d ",dynamicArray[i][z]);
			}
			z++;
		}
    i++;
		fprintf(entries2,"\n");
	}


//freeing memory allcaoted so far as it is no longer useful
  for(int i = 0; i < j; ++i)
  {
    free(dynamicArray[i]);
  }
  free(dynamicArray);


  for(int i = 0; i < j; ++i)
  {
    free(included[i]);
  }
  free(included);


  for(int i = 0; i < j; ++i)
  {
    free(name[i]);
  }
  free(name);
  free(profit);
  free(weight);


return 0;
}
