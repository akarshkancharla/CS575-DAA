#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <math.h>
#include <time.h>
#include<unistd.h> /* getopt */
#include<stdbool.h>

//declaring a struct called Card which stores
//name of item
//weight of each item
//profit of each item
struct Card{
  char name[36];
  int weight;
  int profit;
  int items;
};

int final_entries=0;
//variables named according to lectures notes
int *include;
int item_number=1;
FILE *fp_entries, *fp_output;
int *bestset;
int max_profit=0;
int size;
//knapsack weight
int sack_weight;



//kwf2 implemented as it is from the lecture notes
int kwf2(struct Card* k, int profit,int weight, int i){
//variable names are named same as lectures notes for the ease of understanding
  int bound = profit;
	int j;
	double fraction;
  int C=sack_weight;
  int n=size;
  //if the weight is less than the knapsack weight
	while(weight < C && i< n){//also while there are still items
		if((weight+k[i].weight)<=C){
			weight += k[i].weight;
			bound += k[i].profit;
		}
		else{
			fraction = (double)(C - weight)/(double)k[i].weight;
			weight = C;
			bound += (fraction*(double)k[i].profit);
		}
		i++;
	}
  //returns the bound value
	return bound;
}




void knapsack(struct Card *k,int profit, int weight,int i){

//if the weight is less than the knapsack weight and the profit is greater than the maximum profit so far
	if(weight<= sack_weight && profit > max_profit){
		max_profit = profit;
		final_entries = i;
    //copy the entire include into bestset
		memcpy(bestset,include,sizeof(int)*size);

	}
//variable to check whether a node is promising
  bool promising;

//checking if its promising
  int bound;
  double bound_double;
  if(weight > sack_weight){
    //if the weight is greater than the sack weight, then it is not promising
    fprintf(fp_entries,"%d  %d  %d  0.000\n",item_number++, profit,weight);
    //printf("0.000\n");
    promising=false;
  }
  else{
    bound = kwf2(k,profit,weight,i);
    bound_double=bound;
    //output to a textfile
    fprintf(fp_entries,"%d  %d  %d  %0.3f\n",item_number++, profit,weight,bound_double);
    //1 for promising 0, for not promising
    promising= bound > max_profit;

  }

//if the node is promising
	if(promising){
		include[i] = 1;
		knapsack(k, profit+k[i].profit,weight+k[i].weight,i+1);
		include[i] = 0;
		knapsack(k,profit,weight,i+1);
	}
  else{
    //printf("0.000\n");
  }

}




//if the input is not sorted, we need to sort it before applying knapsack
void sorted(struct Card *k){
  char temp_name[36];
  int j=0;
	double temp1;
  double temp2;
  int temp;

  int i=0;
  while(i<size){
		temp1 = (double)k[i].profit/ (double)k[i].weight;
    j=i+1;
    while(j<size){
			temp2 = (double)k[j].profit/ (double)k[j].weight;
//sorting in descending order
			if(temp2 > temp1){
//swapping logic
        strcpy(temp_name,k[i].name);
        strcpy(k[i].name,k[j].name);
        strcpy(k[j].name,temp_name);

        temp= k[i].weight;
        k[i].weight=k[j].weight;
        k[j].weight=temp;

        temp= k[i].profit;
        k[i].profit=k[j].profit;
        k[j].profit=temp;

				temp1 = temp2;
			}
      j++;
		}
    i++;
	}


}


void backtrack(struct Card *k){
  sorted(k);
//dynamically allocate memory
  int i;
  include = malloc(sizeof(int)*size);
//setting include to zero initially
  for(int z=0;z<size;z++)
  {
    include[z]=0;
  }
  bestset = malloc(sizeof(int)*size);
//initializing bestset to zero in the beginning
  for(int z=0;z<size;z++)
  {
    bestset[z]=0;
  }

  max_profit = -1;
  fp_entries=fopen("entries3.txt","w+");
//if open is not successful
  if ( fp_entries == NULL )
   {
       printf( "File open failed\n" );
   }

//call to knapsack function
	knapsack(k,0,0,0);


}






int main(int argc, char *argv[]){

  clock_t begin;
  clock_t end;
  FILE  *knapsack_file, *output_file;
  int line;
  char *line_buf = NULL;
  size_t line_buf_size = 0;
  int return_value=0;
  int c,i;
  int possible_weight=0;
  fp_output=fopen("output3.txt","w+");

    int opt;
    while((opt = getopt(argc, argv, "k:"))!=-1) {

        switch (opt) {
        case 'k':
           knapsack_file=fopen(optarg,"r");
           break;

        default:
            /* Unexpected option */
           return 1;
        }
    }





        c=getline(&line_buf,&line_buf_size,knapsack_file);


          size=atoi(strtok(line_buf," "));
          struct Card knapsack_node[size];
          sack_weight=atoi(strtok(NULL," "));
          i=0;
          //while there are more items
          while(i<size){
              c=getline(&line_buf,&line_buf_size,knapsack_file);
              strcpy(knapsack_node[i].name,strtok(line_buf," "));
              knapsack_node[i].profit=atoi(strtok(NULL," "));
              knapsack_node[i].weight=atoi(strtok(NULL," "));
              i++;
          }

          backtrack(knapsack_node);

          i=0;
          while(i<size){
            if(bestset[i]){
              possible_weight += knapsack_node[i].weight;
            }
            i++;
          }

//outputting to a file
          fprintf(fp_output,"%d %d %d\n",final_entries,max_profit,possible_weight);
          i=0;
          //while there are more items
          while(i<size){
            if(bestset[i]){
              fprintf(fp_output,"%s %d %d\n",knapsack_node[i].name,knapsack_node[i].profit, knapsack_node[i].weight);
            }
            i++;
          }
          //freeing all the allocated memory as it is now useless
          free(include);
          free(bestset);

          //closing all the opened file descriptors
          fclose(knapsack_file);
          fclose(fp_output);
          fclose(fp_entries);
          return 0;

}
