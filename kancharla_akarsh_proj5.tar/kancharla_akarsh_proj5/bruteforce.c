
//edited from assignment1
#include <stdio.h> /* fprintf */
#include <stdlib.h>
#include <unistd.h> /* getopt */
#include<string.h>
#include<math.h>
#include<time.h>

//struct to store the name of item,it's weight, profit
struct Card{
  char name[36];
  int weight;
  int profit;
};






void compute_max_profit(struct Card iset[], int w,int j){

  int maxProfit=0,maxWeight=0;
  int n_subsets;
  int max_count=0;
  //struct Card *s=(struct Card *) malloc(sizeof(struct Card)*j);
  //struct Card *m=(struct Card *) malloc(sizeof(struct Card)*j);
  int x=0;
  int sum_of_weights=0;
  int sum_of_weights_s=0;
  int profit_s=0;
  int count=0;
  FILE *fp;


  while(x < j){
      sum_of_weights+=iset[x].weight;
      x++;
  }
  //printf("%d  %d\n",sum_of_weights,w);
  x=0;

  if(sum_of_weights<=w){
    while(x < j){
        maxProfit+=iset[x].profit;
        x++;
    }
   //write  a return call with the structure as return value

   //return maxProfit;
  }

  int b;
  n_subsets=pow(2.0,j);
  //printf("%d\n",n_subsets);
  int subset[j];
  int m[j];
  int g=0;

  while(g<j){
    subset[g]=0;
    g++;
  }


  for(int y=0; y < n_subsets; y++){ //while more subsets to generate
    b = 1;

    sum_of_weights_s=0;
    profit_s=0;
    count=0;
    g=0;

    while(g<j){
      subset[g] = subset[g] + b;
			b = subset[g]/2;
			subset[g] = subset[g]%2;
      g++;
    }

    for(int z=0;z<j;z++){
      if(subset[z]==1){
        count++;
        sum_of_weights_s+=iset[z].weight;
        profit_s+=iset[z].profit;
      }
    }




    if (sum_of_weights_s<=w){
      if (profit_s > maxProfit){
        maxProfit=profit_s;
        maxWeight=sum_of_weights_s;
        max_count=count;
        for (int i=0; i<j; i++) {
            m[i] = subset[i]; //copy the whole struct s to m
            //printf("%s %d  %d\n",m[i].name,m[i].profit,m[i].weight);


        }
      }
    }

  }

//outputting to a file
  fp=fopen("output1.txt","w+");
  if ( fp == NULL )
   {
       printf( "File open failed\n" );
   }

   fprintf(fp,"%d %d  %d\n",max_count,maxProfit,maxWeight);
   //printf("%d %d  %d\n",max_count,maxProfit,maxWeight);
   for(int i=0;i<j;i++)
   {
       if(m[i]==1)
       {
       fprintf(fp,"%s %d  %d\n",iset[i].name,iset[i].profit,iset[i].weight);
       //printf("%s %d  %d\n",iset[i].name,iset[i].profit,iset[i].weight);
       }

   }



  //free(s);
  fclose(fp);






}







int main(int argc, char *argv[]){
  int j;
  clock_t begin;
  clock_t end;
  FILE  *knapsack_file, *output_file;
  int line;
  char *line_buf = NULL;
  size_t line_buf_size = 0;
  int return_value=0;
  //int pro=0;
  int c,i;
  //output_file=fopen("output.txt","w+");

    int opt;
    while((opt = getopt(argc, argv, "k:"))!=-1) {

        switch (opt) {
        case 'k':
           knapsack_file=fopen(optarg,"r");
           break;

        default:
            /* Unexpected option */
           return 1;
        }
    }


//file parsing

    int total_weight;

    c=getline(&line_buf,&line_buf_size,knapsack_file);


      j=atoi(strtok(line_buf," "));
      struct Card g_cards[j];
      total_weight=atoi(strtok(NULL," "));
      i=0;
      while(i<j){
          c=getline(&line_buf,&line_buf_size,knapsack_file);
          strcpy(g_cards[i].name,strtok(line_buf," "));
          g_cards[i].profit=atoi(strtok(NULL," "));
          g_cards[i].weight=atoi(strtok(NULL," "));
          i++;
      }



     compute_max_profit(g_cards,total_weight,j);
     //printf("max profit is %d",pro);
     //printf("%d\n",compute_max_profit(g_cards,total_weight));
     //printf("%d\n",max_count);

     //fputc(j,output_file);//size of input
     //fputc(atoi(" "),output_file);
     //fputc(pro,output_file);//max profit
     //fputc(atoi(" "),output_file);
     //fputc(max_count,output_file);//count of max subset array
     //fputc(atoi(" "),output_file);
     //fputc((end-begin),output_file);//time for running

     //fprintf(output_file, "%d %d %d %f\n", j, pro, max_count, ((double)(end - begin)) / CLOCKS_PER_SEC);
     //fputc(atoi("\n"),output_file);
/*
     int i=0;
      while(i<j){
        printf("%s  ",g_cards[i].name);
        printf("%d\n",g_cards[i].price );
        printf("%d\n",g_cards[i].profit );
        i++;
      }
*/

    fclose(knapsack_file);
    //fclose(output_file);
    return 0;
}
