To compile the program 
use 'make' command ('make' runs the following command: gcc -o tromino tromino_order.c -lm)

To run the program use 
./tromino