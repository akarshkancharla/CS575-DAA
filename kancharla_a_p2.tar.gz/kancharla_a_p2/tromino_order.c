#include <stdio.h>
#include <math.h>
#include <stdlib.h>


int board_size;
enum Pos{LL=1,LR=2,UL=3,UR=4};

int block_type(int x, int y, int new_x, int new_y, int x_missing, int y_missing){
  if(x_missing>x && y_missing>y && x_missing >= new_x && y_missing >= new_y)
  {
    return UL;
  }
  if(x_missing>=x && y_missing>y && x_missing < new_x && y_missing >= new_y)
  {
    return LL;
  }
  if(x_missing>x && y_missing >= y && x_missing >= new_x && y_missing < new_y)
  {
    return UR;
  }
  if(x_missing>=x && y_missing >= y && x_missing < new_x && y_missing < new_y)
  {
    return LR;
  }

}

void show(int bSize, int trominoBoard[bSize][bSize])
{
	int k;
	int l;
	for( k = 0; k<bSize;k++)
		{
			for(l = 0; l<bSize; l++)
			{
        if(trominoBoard[k][l] == -10)
					printf("MS\t");
				else if(trominoBoard[k][l] == LL)
					printf("LL\t");
        else if(trominoBoard[k][l] == LR)
          printf("LR\t");
        else if(trominoBoard[k][l] == UL)
          printf("UL\t");
        else if(trominoBoard[k][l] == UR)
          printf("UR\t");
			}
		printf("\n");

		}
}



void tromino( int x, int y, int x_missing, int y_missing, int newBSize, int trominoBoard[board_size][board_size]){
  int s;

    int x1,y1;
  	int x2,y2;
  	int x3,y3;
  	int x4,y4;

    int new_x = x+newBSize/2;
    int new_y = y+newBSize/2;

  //printf("New bsize %d\n",newBSize);
  if(newBSize==2)
  {
    s=block_type(x,y,new_x,new_y,x_missing,y_missing);
    //printf("Block type %d\n",s );

    for(int k = x; k<x+2; k++)
    {
      for(int l=y; l<y+2; l++)
      {
        if(trominoBoard[k][l] == 0)
        {
          trominoBoard[k][l]=s;
        }
      }
    }
    return;
  }



  if(x_missing>=x && y_missing>y && x_missing < new_x && y_missing >= new_y) //quadrant 1 UR
  {
    //printf("In quad 1\n");
    //find the type of block
    s=block_type(x,y,new_x,new_y,x_missing,y_missing);
      //printf("Block type %d\n",s );

    // Insert block in quad 2,3,4 for the hole
    trominoBoard[new_x-1][new_y-1]=s;//inserting in q2
    trominoBoard[new_x][new_y-1]=s;//inserting in q3
    trominoBoard[new_x][new_y]=s;//inserting in q4
/*
    x1 = new_x-1;
    y1 = new_y-1;
    x2 = new_x-1;
    y2 = new_y;
    x3 = x_missing;
    y3 = y_missing;
    x4 = new_x;
    y4 = new_y;
*/
//holes
x1 = x_missing;
y1 = y_missing;
x2 = new_x-1;
y2 = new_y-1;
x3 = new_x;
y3 = new_y-1;
x4 = new_x;
y4 = new_y;



  }

  if(x_missing>=x && y_missing >= y && x_missing < new_x && y_missing < new_y) //quadrant 2 UL
  {
    //printf("In quad 2\n");
      s=block_type(x,y,new_x,new_y,x_missing,y_missing);
      //printf("Block type %d\n",s );
   trominoBoard[new_x-1][new_y]=s;//inserting in q1
   trominoBoard[new_x][new_y-1]=s;//inserting in q3
   trominoBoard[new_x][new_y]=s;//inserting in q4

   x1 = new_x-1;
   y1 = new_y;
   x2 = x_missing;
   y2 = y_missing;
   x3 = new_x;
   y3 = new_y-1;
   x4 = new_x;
   y4 = new_y;
  }

  if(x_missing>x && y_missing >= y && x_missing >= new_x && y_missing < new_y)//quadrant 3 LL
  {
    //printf("In quad 3\n");
        s=block_type(x,y,new_x,new_y,x_missing,y_missing);
          //printf("Block type %d\n",s );
    trominoBoard[new_x-1][new_y]=s;//inserting in q1
    trominoBoard[new_x-1][new_y-1]=s;//inserting in q2
    trominoBoard[new_x][new_y]=s;//inserting in q4

    x1 = new_x-1;
    y1 = new_y;
    x2 = new_x-1;
    y2 = new_y-1;
    x3 = x_missing;
    y3 = y_missing;
    x4 = new_x;
    y4 = new_y;
  }

  if(x_missing>x && y_missing>y && x_missing >= new_x && y_missing >= new_y) //quadrant 4 LR
  {
    //printf("In quad 4\n");
        s=block_type(x,y,new_x,new_y,x_missing,y_missing);
          //printf("Block type %d\n",s );
    trominoBoard[new_x-1][new_y]=s;//inserting in q1
    trominoBoard[new_x-1][new_y-1]=s;//inserting in q2
    trominoBoard[new_x][new_y-1]=s;//inserting in q3

    x1 = new_x-1;
    y1 = new_y;
    x2 = new_x-1;
    y2 = new_y-1;
    x3 = new_x;
    y3 = new_y-1;
    x4 = x_missing;
    y4 = y_missing;
  }


  tromino( x, new_y, x1, y1, newBSize/2, trominoBoard); //quad 1
  tromino( x, y, x2, y2, newBSize/2, trominoBoard); //quad 2
  tromino( new_x, y, x3, y3, newBSize/2, trominoBoard);//quad 3
  tromino(new_x, new_y,x4, y4, newBSize/2, trominoBoard);//quad 4

}



int main()
{

  int x_missing,y_missing;

  while(1){
  printf("Please input the board size (need to be 2^n) (0 to quit): ");

  scanf("%d",&board_size);

  if(board_size==0)
  {
    return 0;
  }

  if(board_size==0)
  {
    exit(0);
  }
  int board[board_size][board_size];
  int temp_board[board_size][board_size];

  printf("\nPlease enter coordinates of missing square (separate by a space):");
  scanf("%d %d",&x_missing,&y_missing);

  for( int k = 0; k<board_size;k++)
	{
		for(int l = 0; l<board_size; l++)
			board[k][l] = 0;
	}

  //board[x_missing][y_missing] = -10;

  board[board_size-y_missing-1][x_missing]= -10;

/*
  int i,j,p,q;
  for(i=board_size-1,p=0; i>=0, p<board_size ;i--,p++)
    {
    for(j=0,q=0; j<board_size, q<board_size; j++,q++)
      {
       temp_board[j][i]= board[p][q];
      }
    }

    for( int k = 0; k<board_size;k++)
    {
      for(int l = 0; l<board_size; l++){
        printf("%d ",board[k][l]);
      }
      printf("\n");
    }
printf("\n");
      for( int k = 0; k<board_size;k++)
    	{
    		for(int l = 0; l<board_size; l++){
    			printf("%d ",temp_board[k][l]);
        }
        printf("\n");
    	}
      return 0;
*/
  tromino(0,0,board_size-y_missing-1,x_missing,board_size,board);
  show(board_size, board);
}//while ends

  return 0;

}
